#Nama/NRP   : Rizwar Syaefulloh/2c2230009
#Tanggal    : 14 oktober 2024

def tentukan_kelas(nrp):
    # Konversi NRP ke integer
    nrp = int(nrp)
    
    # Tentukan rentang NRP
    if 1 <= nrp <= 100:
        rentang = 1
    elif 101 <= nrp <= 200:
        rentang = 2
    elif 201 <= nrp <= 300:
        rentang = 3
    else:
        rentang = 4

    # Tentukan apakah NRP ganjil atau genap
    if nrp % 2 == 0:
        ganjil_genap = "genap"
    else:
        ganjil_genap = "ganjil"

    # Tentukan kelas berdasarkan rentang dan ganjil/genap
    if rentang == 1:
        kelas = "K1" if ganjil_genap == "ganjil" else "K2"
    elif rentang == 2:
        kelas = "K3" if ganjil_genap == "ganjil" else "K4"
    elif rentang == 3:
        kelas = "K5" if ganjil_genap == "ganjil" else "K6"
    else:
        kelas = "K7" if ganjil_genap == "ganjil" else "K8"

    return kelas

# Menerima input dari pengguna
nrp_akhir = input("Masukan akhiran NRP: ")

# Menentukan kelas dan menampilkan hasilnya
kelas = tentukan_kelas(nrp_akhir)
print(f"Mahasiswa masuk ke kelas {kelas}")